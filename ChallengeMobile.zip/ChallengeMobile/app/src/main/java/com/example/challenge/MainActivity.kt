import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.challenge.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.criar_usuario)
    }

    fun onLoginClick(view: View) {
        val usernameEditText = findViewById<EditText>(R.id.username)
        val passwordEditText = findViewById<EditText>(R.id.password)

        val username = usernameEditText.text.toString()
        val password = passwordEditText.text.toString()

        // Alterando o nome de usuário e senha
        if (username == "new_user" && password == "new_password") {
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Login failed", Toast.LENGTH_SHORT).show()
        }
    }

    fun onForgotPasswordClick(view: View) {
        Toast.makeText(this, "Recuperação de senha iniciada...", Toast.LENGTH_SHORT).show()
    }

    fun onClickAssistant(view: View) {
        Toast.makeText(this, "Falando com o assistente...", Toast.LENGTH_SHORT).show()
    }

    fun onFeedbackClick(view: View) {
        val feedback1 = findViewById<EditText>(R.id.feedbackEditText1).text.toString()
        val feedback2 = findViewById<EditText>(R.id.feedbackEditText2).text.toString()
        val feedback3 = findViewById<EditText>(R.id.feedbackEditText3).text.toString()
        val feedbackEval1 = findViewById<EditText>(R.id.feedbackEvaluationEditText1).text.toString()
        val feedbackEval2 = findViewById<EditText>(R.id.feedbackEvaluationEditText2).text.toString()
        val feedbackEval3 = findViewById<EditText>(R.id.feedbackEvaluationEditText3).text.toString()

        // Simule a exibição dos feedbacks em um Toast (ou outra lógica de processamento)
        val feedbacks = "$feedback1\n$feedback2\n$feedback3\n$feedbackEval1\n$feedbackEval2\n$feedbackEval3"
        Toast.makeText(this, feedbacks, Toast.LENGTH_LONG).show()
    }
}
